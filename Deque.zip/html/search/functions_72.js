var searchData=
[
  ['resize',['resize',['../classMyDeque.html#a2cdd311ea589d2e671fb435c0bdbc198',1,'MyDeque']]]
];
