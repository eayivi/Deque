var searchData=
[
  ['block_5fwidth',['BLOCK_WIDTH',['../Deque_8h.html#aff434668c1f3fab69e5937ecae459c3f',1,'Deque.h']]]
];
