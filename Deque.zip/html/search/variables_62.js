var searchData=
[
  ['block_5fsize',['block_size',['../classMyDeque.html#a9190945eee41207d9482281553d3f874',1,'MyDeque']]]
];
