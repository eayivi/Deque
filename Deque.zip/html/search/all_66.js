var searchData=
[
  ['front',['front',['../classMyDeque.html#ad623f1a67c4e1c18393025d741202eee',1,'MyDeque::front()'],['../classMyDeque.html#acdaaf554e2fc093dc9440df5c5dbce9a',1,'MyDeque::front() const ']]]
];
