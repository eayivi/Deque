var searchData=
[
  ['destroy',['destroy',['../Deque_8h.html#ae5ccf961a6e64163beab1ef8f8934fe5',1,'Deque.h']]]
];
